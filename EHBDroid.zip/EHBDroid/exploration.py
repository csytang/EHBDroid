import os
import sys
os.system("monkeyrunner L:\EHB\ehbdroid.py")