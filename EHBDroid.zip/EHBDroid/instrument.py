import os
import sys

os.system ("java -jar EHBDroid.jar "+sys.argv[1]+" "+ sys.argv[2]) 