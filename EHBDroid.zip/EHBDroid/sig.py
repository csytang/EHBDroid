import os
import sys

apkname = sys.argv[1]
apk = "srcApk/"+apkname+".apk"
sigapk = "desApk/"+apkname+"_1.apk"

os.system("jarsigner -keystore qian.key -storepass 123456 -signedjar "+ sigapk+" -digestalg SHA1 "+apk+" qian.key")