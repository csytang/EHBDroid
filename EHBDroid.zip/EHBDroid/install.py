import sys
import time
import os

apkname = sys.argv[1]
apk = "desApk/"+apkname+".apk"
sigapk = "desApk/"+apkname+"_1.apk"
txt = "seriObjs.txt"
txtlocation = "desApk/"+txt
sdcard = "/mnt/sdcard/"

os.system("jarsigner -keystore qian.key -storepass 123456 -signedjar "+ sigapk+" -digestalg SHA1 "+apk+" qian.key")

print "successfully signature "+apkname

createavd = "android create avd -f -n test -t android-19 -d 14 -s HVGA -c 200M"
os.system(createavd)

print "emulator is created"
time.sleep(20)
os.system("emulator -avd test")
time.sleep(170)
print "emulator starts"
os.system( "adb install -r "+sigapk)
os.system ("adb push "+apk+" "+sdcard+apkname+".apk")
os.system ("adb push "+txtlocation +" "+sdcard+txt)